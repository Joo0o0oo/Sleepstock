import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowLeft,
  Sparkles,
  Loader2,
  Droplets,
  Flame,
  Moon,
  Bird,
  Eye,
  KeyRound,
  Star,
  DoorOpen,
  Trees,
  Mountain,
  RefreshCw,
  Bookmark,
  BookmarkCheck,
  Share2,
  Check,
} from "lucide-react";
import { MobileShell } from "@/components/MobileShell";
import { getDreams, type Dream } from "@/lib/dreams-store";
import { DESEOS_CATALOG } from "@/lib/deseos-catalog";
import { analyzeSubconscious, type SubconsciousAnalysis } from "@/lib/deseos.functions";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/sueno/deseos")({
  head: () => ({
    meta: [
      { title: "Deseos del Subconsciente — Sleep Stock" },
      {
        name: "description",
        content: "Análisis profundo de tus sueños: necesidades, símbolos y recomendaciones personalizadas.",
      },
    ],
  }),
  component: DeseosPage,
});

type Range = "7" | "30" | "90" | "all";

const RANGES: { id: Range; label: string }[] = [
  { id: "7", label: "7 días" },
  { id: "30", label: "30 días" },
  { id: "90", label: "90 días" },
  { id: "all", label: "Todos" },
];

const ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  water: Droplets,
  fire: Flame,
  moon: Moon,
  bird: Bird,
  eye: Eye,
  key: KeyRound,
  star: Star,
  door: DoorOpen,
  forest: Trees,
  mirror: Eye,
  mountain: Mountain,
};

const STORAGE_KEY = "sleepstock.deseos.saved";

type SavedAnalysis = {
  id: string;
  savedAt: number;
  range: Range;
  dreamCount: number;
  analysis: SubconsciousAnalysis;
};

function loadSaved(): SavedAnalysis[] {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "[]");
  } catch {
    return [];
  }
}

function persistSaved(items: SavedAnalysis[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  } catch {
    // ignore quota errors
  }
}

function buildShareText(a: SubconsciousAnalysis, rangeLabel: string): string {
  const needs = a.necesidades
    .slice(0, 3)
    .map((n) => `• ${n.label} ${n.percentage}%`)
    .join("\n");
  const symbols = a.simbolos
    .slice(0, 4)
    .map((s) => s.nombre)
    .join(", ");
  return [
    `🌙 Mi lectura del subconsciente (${rangeLabel})`,
    "",
    a.lectura.slice(0, 280),
    "",
    "Necesidades:",
    needs,
    "",
    `Símbolos: ${symbols}`,
    "",
    "— Sleep Stock",
  ].join("\n");
}

function parseSpanishDate(s: string): Date | null {
  // formats like "25 de Marzo, 2026"
  const meses: Record<string, number> = {
    enero: 0, febrero: 1, marzo: 2, abril: 3, mayo: 4, junio: 5,
    julio: 6, agosto: 7, septiembre: 8, octubre: 9, noviembre: 10, diciembre: 11,
  };
  const m = s.toLowerCase().match(/(\d+)\s+de\s+(\w+),?\s+(\d{4})/);
  if (!m) return null;
  const month = meses[m[2]];
  if (month == null) return null;
  return new Date(Number(m[3]), month, Number(m[1]));
}

function filterDreams(dreams: Dream[], range: Range): Dream[] {
  if (range === "all") return dreams;
  const days = Number(range);
  const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
  return dreams.filter((d) => {
    const parsed = parseSpanishDate(d.date);
    if (!parsed) return true;
    return parsed.getTime() >= cutoff;
  });
}

function DeseosPage() {
  const [range, setRange] = useState<Range>("30");
  const [analysis, setAnalysis] = useState<SubconsciousAnalysis | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [savedIds, setSavedIds] = useState<string[]>([]);
  const [currentId, setCurrentId] = useState<string | null>(null);
  const [shareStatus, setShareStatus] = useState<"idle" | "copied">("idle");
  const allDreams = useMemo(() => getDreams(), []);
  const filtered = useMemo(() => filterDreams(allDreams, range), [allDreams, range]);
  const analyze = useServerFn(analyzeSubconscious);

  useEffect(() => {
    setSavedIds(loadSaved().map((s) => s.id));
  }, []);

  async function run() {
    if (filtered.length === 0) return;
    setLoading(true);
    setError(null);
    setAnalysis(null);
    setCurrentId(null);
    try {
      const res = await analyze({
        data: {
          dreams: filtered.slice(0, 30).map((d) => ({
            title: d.title,
            analysis: d.analysis,
            date: d.date,
          })),
          catalog: DESEOS_CATALOG.map((c) => ({ id: c.id, title: c.title, category: c.category })),
        },
      });
      setAnalysis(res);
      setCurrentId(`a_${Date.now()}`);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error inesperado");
    } finally {
      setLoading(false);
    }
  }

  const isSaved = currentId != null && savedIds.includes(currentId);

  function handleSave() {
    if (!analysis || !currentId) return;
    const existing = loadSaved();
    if (existing.some((s) => s.id === currentId)) {
      const filtered = existing.filter((s) => s.id !== currentId);
      persistSaved(filtered);
      setSavedIds(filtered.map((s) => s.id));
      return;
    }
    const rangeLabel = RANGES.find((r) => r.id === range)?.label ?? "";
    const entry: SavedAnalysis = {
      id: currentId,
      savedAt: Date.now(),
      range,
      dreamCount: filtered.length,
      analysis,
    };
    const next = [entry, ...existing].slice(0, 20);
    persistSaved(next);
    setSavedIds(next.map((s) => s.id));
    void rangeLabel;
  }

  async function handleShare() {
    if (!analysis) return;
    const rangeLabel = RANGES.find((r) => r.id === range)?.label ?? "";
    const text = buildShareText(analysis, rangeLabel);
    const shareData = {
      title: "Mi lectura del subconsciente",
      text,
    };
    try {
      if (typeof navigator !== "undefined" && (navigator as any).share) {
        await (navigator as any).share(shareData);
        return;
      }
    } catch {
      // fall through to clipboard
    }
    try {
      await navigator.clipboard.writeText(text);
      setShareStatus("copied");
      setTimeout(() => setShareStatus("idle"), 2000);
    } catch {
      setShareStatus("idle");
    }
  }

  useEffect(() => {
    if (filtered.length > 0) void run();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [range]);

  return (
    <MobileShell>
      <div
        className="min-h-screen text-foreground"
        style={{
          background:
            "radial-gradient(120% 80% at 20% 0%, rgba(107,33,217,0.10), transparent 60%), radial-gradient(120% 80% at 80% 100%, rgba(138,56,245,0.08), transparent 60%), #F7F5FB",
        }}
      >
        <header className="sticky top-0 z-20 flex items-center gap-3 px-5 py-4 backdrop-blur-xl bg-white/80 border-b border-[rgba(107,33,217,0.14)]">
          <Link
            to="/sueno"
            className="grid h-9 w-9 place-items-center rounded-full bg-white ring-1 ring-[rgba(107,33,217,0.22)] shadow-sm"
          >
            <ArrowLeft className="h-4 w-4 text-primary" />
          </Link>
          <div className="flex-1">
            <p className="text-[10px] font-bold tracking-[0.25em] text-muted-foreground">ANÁLISIS PROFUNDO</p>
            <h1 className="text-lg font-bold text-foreground">Deseos del Subconsciente</h1>
          </div>
          <div
            className="grid h-10 w-10 place-items-center rounded-[10px]"
            style={{
              background: "linear-gradient(135deg, #6B21D9, #8A38F5)",
              boxShadow: "0 8px 20px -6px rgba(107,33,217,0.45)",
            }}
          >
            <Sparkles className="h-5 w-5 text-white" />
          </div>
        </header>

        <div className="px-5 pt-4 pb-32 space-y-5">
          {/* Range selector */}
          <div className="scrollbar-hide -mx-5 flex gap-2 overflow-x-auto px-5">
            {RANGES.map((r) => {
              const active = range === r.id;
              return (
                <button
                  key={r.id}
                  onClick={() => setRange(r.id)}
                  className={cn(
                    "shrink-0 rounded-full px-4 py-2 text-xs font-semibold transition",
                    active
                      ? "bg-primary text-primary-foreground shadow-[0_8px_20px_-6px_rgba(107,33,217,0.45)]"
                      : "bg-white text-foreground/70 ring-1 ring-[rgba(107,33,217,0.20)] hover:bg-[rgba(107,33,217,0.06)] hover:text-foreground",
                  )}
                >
                  {r.label}
                </button>
              );
            })}
          </div>

          <p className="text-xs text-muted-foreground">
            {filtered.length} {filtered.length === 1 ? "sueño analizado" : "sueños analizados"} en
            este período
          </p>

          {filtered.length === 0 && (
            <GlassCard>
              <p className="text-sm text-foreground/80">
                Aún no hay sueños registrados en este período.
              </p>
              <Link
                to="/sueno/chat"
                className="mt-3 inline-flex items-center gap-2 rounded-[10px] bg-primary px-4 py-2 text-xs font-semibold text-primary-foreground"
              >
                Registrar un sueño →
              </Link>
            </GlassCard>
          )}

          {loading && <LoadingState />}

          {error && (
            <GlassCard>
              <p className="text-sm text-destructive">{error}</p>
              <button
                onClick={run}
                className="mt-3 inline-flex items-center gap-2 rounded-[10px] bg-white px-4 py-2 text-xs font-semibold text-foreground ring-1 ring-[rgba(107,33,217,0.22)] hover:bg-[rgba(107,33,217,0.06)]"
              >
                <RefreshCw className="h-3 w-3" /> Reintentar
              </button>
            </GlassCard>
          )}

          <AnimatePresence>
            {analysis && !loading && (
              <motion.div
                key="result"
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="space-y-5"
              >
                {/* Lectura */}
                <GlassCard>
                  <div className="flex items-start justify-between gap-3">
                    <SectionLabel>Lectura del Subconsciente</SectionLabel>
                    <div className="flex shrink-0 items-center gap-2">
                      <button
                        onClick={handleSave}
                        aria-label={isSaved ? "Quitar de guardados" : "Guardar análisis"}
                        className={cn(
                          "inline-flex items-center gap-1.5 rounded-[10px] px-3 py-1.5 text-[11px] font-semibold ring-1 transition",
                          isSaved
                            ? "bg-primary text-primary-foreground ring-primary/40"
                            : "bg-white text-foreground ring-[rgba(107,33,217,0.22)] hover:bg-[rgba(107,33,217,0.06)]",
                        )}
                      >
                        {isSaved ? (
                          <BookmarkCheck className="h-3.5 w-3.5" />
                        ) : (
                          <Bookmark className="h-3.5 w-3.5" />
                        )}
                        {isSaved ? "Guardado" : "Guardar"}
                      </button>
                      <button
                        onClick={handleShare}
                        aria-label="Compartir análisis"
                        className="inline-flex items-center gap-1.5 rounded-[10px] bg-white px-3 py-1.5 text-[11px] font-semibold text-foreground ring-1 ring-[rgba(107,33,217,0.22)] transition hover:bg-[rgba(107,33,217,0.06)]"
                      >
                        {shareStatus === "copied" ? (
                          <Check className="h-3.5 w-3.5" />
                        ) : (
                          <Share2 className="h-3.5 w-3.5" />
                        )}
                        {shareStatus === "copied" ? "Copiado" : "Compartir"}
                      </button>
                    </div>
                  </div>
                  <p className="mt-2 whitespace-pre-line text-sm leading-relaxed text-foreground/85">
                    {analysis.lectura}
                  </p>
                </GlassCard>

                {/* Necesidades */}
                <GlassCard>
                  <SectionLabel>Necesidades Detectadas</SectionLabel>
                  <div className="mt-4 space-y-4">
                    {analysis.necesidades.map((n, i) => (
                      <div key={i}>
                        <div className="flex items-baseline justify-between">
                          <p className="text-sm font-semibold text-foreground">{n.label}</p>
                          <p className="text-xs font-bold text-primary">{n.percentage}%</p>
                        </div>
                        <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-[rgba(107,33,217,0.10)]">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${n.percentage}%` }}
                            transition={{ duration: 0.8, delay: i * 0.1 }}
                            className="h-full rounded-full"
                            style={{
                              background: "linear-gradient(90deg, #6B21D9, #8A38F5)",
                            }}
                          />
                        </div>
                        {n.descripcion && (
                          <p className="mt-1 text-[11px] text-muted-foreground">{n.descripcion}</p>
                        )}
                      </div>
                    ))}
                  </div>
                </GlassCard>

                {/* Símbolos */}
                <GlassCard>
                  <SectionLabel>Símbolos Recurrentes</SectionLabel>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {analysis.simbolos.map((s, i) => {
                      const Icon = ICONS[s.icono?.toLowerCase()] ?? Star;
                      return (
                        <div
                          key={i}
                          className="flex items-center gap-2 rounded-[10px] bg-white px-3 py-1.5 text-xs ring-1 ring-[rgba(107,33,217,0.20)]"
                        >
                          <Icon className="h-3.5 w-3.5 text-primary" />
                          <span className="text-foreground font-medium">{s.nombre}</span>
                        </div>
                      );
                    })}
                  </div>
                </GlassCard>

                {/* Recomendaciones */}
                <div>
                  <SectionLabel>Recomendaciones Personalizadas</SectionLabel>
                  <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
                    {analysis.recomendaciones.map((r, i) => {
                      const item = DESEOS_CATALOG.find((c) => c.id === r.id);
                      if (!item) return null;
                      return (
                        <motion.div
                          key={r.id}
                          initial={{ opacity: 0, y: 12 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: i * 0.08 }}
                          className="overflow-hidden rounded-[10px] bg-white ring-1 ring-[rgba(107,33,217,0.16)]"
                          style={{ boxShadow: "0 8px 24px -12px rgba(107,33,217,0.30)" }}
                        >
                          <div className="relative h-32 w-full overflow-hidden">
                            <img
                              src={item.image}
                              alt=""
                              aria-hidden
                              className="h-full w-full object-cover"
                              loading="lazy"
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/55 via-black/10 to-transparent" />
                            <span className="absolute left-3 top-3 rounded-[10px] bg-white/90 px-2.5 py-1 text-[10px] font-bold tracking-wide text-foreground ring-1 ring-[rgba(107,33,217,0.20)] backdrop-blur">
                              {item.category}
                            </span>
                            <div
                              className="absolute right-3 top-3 rounded-[10px] px-2.5 py-1 text-[11px] font-bold text-white"
                              style={{
                                background: "linear-gradient(135deg, #6B21D9, #8A38F5)",
                                boxShadow: "0 4px 12px -2px rgba(107,33,217,0.50)",
                              }}
                            >
                              {r.afinidad}%
                            </div>
                          </div>
                          <div className="space-y-2 p-4">
                            <p className="text-sm font-semibold leading-tight text-foreground">
                              {item.title}
                            </p>
                            <p className="text-[11px] leading-relaxed text-muted-foreground">
                              {r.motivo}
                            </p>
                            <button
                              className="mt-2 w-full rounded-[10px] bg-primary px-3 py-2 text-xs font-semibold text-primary-foreground transition hover:bg-[#7A28E8]"
                            >
                              {item.cta}
                            </button>
                          </div>
                        </motion.div>
                      );
                    })}
                  </div>
                </div>

                <p className="px-2 text-center text-[10px] text-muted-foreground">
                  Contenido reflexivo generado por IA. No constituye diagnóstico médico.
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </MobileShell>
  );
}

function GlassCard({ children }: { children: React.ReactNode }) {
  return (
    <div
      className="rounded-[10px] bg-white p-5 ring-1 ring-[rgba(107,33,217,0.16)]"
      style={{ boxShadow: "0 4px 20px -10px rgba(107,33,217,0.25)" }}
    >
      {children}
    </div>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <p className="text-[10px] font-bold tracking-[0.25em] text-muted-foreground">
      {String(children).toUpperCase()}
    </p>
  );
}

function LoadingState() {
  return (
    <GlassCard>
      <div className="flex items-center gap-3">
        <Loader2 className="h-5 w-5 animate-spin text-primary" />
        <p className="text-sm text-foreground/75">Escaneando tu subconsciente…</p>
      </div>
      <div className="mt-4 space-y-2">
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            className="h-3 animate-pulse rounded-full bg-[rgba(107,33,217,0.10)]"
            style={{ width: `${90 - i * 15}%` }}
          />
        ))}
      </div>
    </GlassCard>
  );
}