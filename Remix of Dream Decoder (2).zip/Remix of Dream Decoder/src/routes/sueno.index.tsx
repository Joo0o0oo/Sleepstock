import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, MessageCircle, BrainCircuit, ChevronRight, Sparkles, Disc3 } from "lucide-react";

import { MobileShell } from "@/components/MobileShell";
import dream1 from "@/assets/dream-1.jpg";
import dreamProgrammer from "@/assets/dream-programmer.jpg";

export const Route = createFileRoute("/sueno/")({
  head: () => ({
    meta: [
      { title: "Sueños — Sleep Stock" },
      { name: "description", content: "Elegí cómo trabajar con tus sueños." },
    ],
  }),
  component: SuenoHub,
});

function SuenoHub() {
  return (
    <MobileShell>
      <header className="sticky top-0 z-20 flex items-center gap-3 bg-background/80 px-5 py-4 backdrop-blur-xl">
        <Link to="/" className="grid h-9 w-9 place-items-center rounded-full bg-white shadow">
          <ArrowLeft className="h-4 w-4 text-primary" />
        </Link>
        <div>
          <p className="text-[10px] tracking-[0.25em] text-muted-foreground">EXPLORÁ</p>
          <h1 className="text-lg font-bold text-primary">Sueños</h1>
        </div>
      </header>

      <div className="px-5 pt-2 pb-32 space-y-4">
        <p className="text-sm text-muted-foreground">
          Elegí qué querés hacer con tus sueños.
        </p>

        <HubCard
          to="/sueno/archivo"
          eyebrow="DISPOSITIVO"
          title="Archivo Onírico"
          desc="Tus sueños capturados por la HYPN Band. Reproducilos cuando quieras."
          icon={<Disc3 className="h-5 w-5" />}
          image={dream1}
        />

        <HubCard
          to="/sueno/chat"
          eyebrow="INTERPRETACIÓN"
          title="Chat Bot de Sueños"
          desc="Contale tu sueño a la IA y recibí un análisis simbólico al instante."
          icon={<MessageCircle className="h-5 w-5" />}
          image={dream1}
        />

        <HubCard
          to="/sueno/programmer"
          eyebrow="PROGRAMACIÓN"
          title="Dream Programmer"
          desc="Programá el sueño que querés tener con un prompt, fecha y banda sonora."
          icon={<BrainCircuit className="h-5 w-5" />}
          image={dreamProgrammer}
        />

        <HubCard
          to="/sueno/deseos"
          eyebrow="ANÁLISIS PROFUNDO"
          title="Deseos del Subconsciente"
          desc="Descubrí qué desea tu mente a partir del patrón de tus sueños."
          icon={<Sparkles className="h-5 w-5" />}
          image={dream1}
        />

      </div>
    </MobileShell>
  );
}

function HubCard({
  to,
  eyebrow,
  title,
  desc,
  icon,
  image,
}: {
  to: "/sueno/chat" | "/sueno/programmer" | "/sueno/deseos" | "/sueno/archivo";
  eyebrow: string;
  title: string;
  desc: string;
  icon: React.ReactNode;
  image: string;
}) {
  return (
    <Link
      to={to}
      className="group block overflow-hidden rounded-3xl bg-card ring-1 ring-border shadow-[var(--shadow-soft)] transition active:scale-[0.98]"
    >
      <div className="relative h-36 w-full overflow-hidden">
        <img src={image} alt="" aria-hidden className="h-full w-full object-cover" loading="lazy" />
        <div
          className="absolute inset-0"
          style={{ background: "linear-gradient(180deg, transparent 30%, oklch(0.18 0.05 280 / 0.7))" }}
        />
        <div
          className="absolute left-4 top-4 grid h-10 w-10 place-items-center rounded-2xl text-white shadow-[var(--shadow-glow)]"
          style={{ background: "var(--gradient-primary)" }}
        >
          {icon}
        </div>
        <p className="absolute bottom-3 left-4 text-[10px] font-semibold tracking-[0.25em] text-white/90">
          {eyebrow}
        </p>
      </div>
      <div className="flex items-center gap-3 px-4 py-4">
        <div className="flex-1">
          <p className="font-bold text-primary">{title}</p>
          <p className="mt-0.5 text-xs text-muted-foreground">{desc}</p>
        </div>
        <ChevronRight className="h-5 w-5 text-primary transition group-hover:translate-x-0.5" />
      </div>
    </Link>
  );
}