import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowLeft,
  BrainCircuit,
  CalendarClock,
  CalendarIcon,
  Check,
  ChevronLeft,
  ChevronRight,
  Music,
  Pencil,
  Play,
  X,
  Trash2,
  Zap,
} from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import { motion, AnimatePresence } from "framer-motion";
import { MobileShell } from "@/components/MobileShell";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import {
  type Frequency,
  type ScheduledDream,
  detectPlatform,
  deleteScheduled,
  getScheduled,
  saveScheduled,
  updateScheduled,
} from "@/lib/dream-programmer-store";
import ciborgImg from "@/assets/skins/ciborg.png.asset.json";
import nomadaImg from "@/assets/skins/nomada.png.asset.json";
import realezaImg from "@/assets/skins/realeza.png.asset.json";
import serLuzImg from "@/assets/skins/ser-luz.png.asset.json";

export const Route = createFileRoute("/sueno/programmer")({
  head: () => ({
    meta: [
      { title: "Dream Programmer — Sleep Stock" },
      { name: "description", content: "Programá inyecciones oníricas en tu cerebro." },
    ],
  }),
  component: DreamProgrammer,
});

const SKINS = [
  { id: "ciborg",  name: "Cíborg Aumentado", tag: "200 D-Coins",       gradient: "linear-gradient(135deg,#06b6d4,#3b0764)", image: ciborgImg.url },
  { id: "realeza", name: "Realeza Astral",   tag: "Edición Limitada",  gradient: "linear-gradient(135deg,#fde047,#a16207)", image: realezaImg.url },
  { id: "nomada",  name: "Nómada del Vacío", tag: "150 D-Coins",       gradient: "linear-gradient(135deg,#374151,#0f172a)", image: nomadaImg.url },
  { id: "etereo",  name: "Ser de Luz",        tag: "Skin Especial",     gradient: "linear-gradient(135deg,#a78bfa,#f0abfc)", image: serLuzImg.url },
] as const;

const SCENES = [
  { id: "ciberpunk", name: "Metrópolis Ciberpunk", tag: "Escenario Premium", gradient: "linear-gradient(120deg,#ec4899,#6366f1,#0ea5e9)", image: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=600&q=80" },
  { id: "orbita",    name: "Órbita Estelar",        tag: "Edición Cosmos",    gradient: "linear-gradient(120deg,#1e1b4b,#7c3aed,#000000)", image: "https://images.unsplash.com/photo-1462331940025-496dfbfc7564?auto=format&fit=crop&w=600&q=80" },
  { id: "oasis",     name: "Oasis Cuántico",        tag: "Edición Limitada",  gradient: "linear-gradient(120deg,#10b981,#06b6d4,#fde047)", image: "https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=600&q=80" },
] as const;

const FREQUENCIES: { id: NonNullable<Frequency>; label: string; hz: string }[] = [
  { id: "theta", label: "Theta", hz: "6 Hz" },
  { id: "delta", label: "Delta", hz: "2 Hz" },
  { id: "gamma", label: "Gamma", hz: "40 Hz" },
];

function skinById(id?: string) {
  return SKINS.find((s) => s.id === id);
}
function sceneById(id?: string) {
  return SCENES.find((s) => s.id === id);
}
function freqById(id?: Frequency) {
  return FREQUENCIES.find((f) => f.id === id);
}

function combineDateTime(date: Date | undefined, time: string): Date | null {
  if (!date) return null;
  const [h, m] = (time || "00:00").split(":").map((n) => parseInt(n, 10) || 0);
  const d = new Date(date);
  d.setHours(h, m, 0, 0);
  return d;
}

function DreamProgrammer() {
  const [prompt, setPrompt] = useState("");
  const [date, setDate] = useState<Date | undefined>(undefined);
  const [time, setTime] = useState("23:00");
  const [mediaUrl, setMediaUrl] = useState("");
  const [skinId, setSkinId] = useState<string | undefined>();
  const [sceneId, setSceneId] = useState<string | undefined>();
  const [frequency, setFrequency] = useState<Frequency>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [items, setItems] = useState<ScheduledDream[]>([]);
  const [isInjecting, setIsInjecting] = useState(false);
  const [trailerId, setTrailerId] = useState<string | null>(null);
  const formRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setItems(getScheduled());
  }, []);

  const platform = useMemo(() => detectPlatform(mediaUrl), [mediaUrl]);
  const scheduledAt = combineDateTime(date, time);
  const canSubmit = !!skinId && !!sceneId && !!scheduledAt;

  function resetForm() {
    setPrompt("");
    setDate(undefined);
    setTime("23:00");
    setMediaUrl("");
    setSkinId(undefined);
    setSceneId(undefined);
    setFrequency(null);
    setEditingId(null);
  }

  function persist() {
    if (!scheduledAt) return;
    if (editingId) {
      updateScheduled(editingId, {
        prompt: prompt.trim(),
        scheduledAt: scheduledAt.toISOString(),
        mediaUrl: mediaUrl.trim() || undefined,
        platform,
        skinId,
        sceneId,
        frequency,
      });
    } else {
      saveScheduled({
        id: String(Date.now()),
        prompt: prompt.trim(),
        scheduledAt: scheduledAt.toISOString(),
        mediaUrl: mediaUrl.trim() || undefined,
        platform,
        createdAt: new Date().toISOString(),
        skinId,
        sceneId,
        frequency,
      });
    }
    setItems(getScheduled());
    resetForm();
  }

  function submit() {
    if (!canSubmit || isInjecting) return;
    setIsInjecting(true);
    window.setTimeout(() => {
      persist();
      setIsInjecting(false);
    }, 2000);
  }

  function startEdit(it: ScheduledDream) {
    setEditingId(it.id);
    setPrompt(it.prompt);
    const d = new Date(it.scheduledAt);
    setDate(d);
    setTime(`${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`);
    setMediaUrl(it.mediaUrl ?? "");
    setSkinId(it.skinId);
    setSceneId(it.sceneId);
    setFrequency(it.frequency ?? null);
    setTimeout(() => formRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 40);
  }

  function removeItem(id: string) {
    deleteScheduled(id);
    setItems(getScheduled());
    if (editingId === id) resetForm();
  }

  const sorted = [...items].sort(
    (a, b) => new Date(a.scheduledAt).getTime() - new Date(b.scheduledAt).getTime(),
  );

  return (
    <MobileShell>
      <header className="sticky top-0 z-20 flex items-center gap-3 bg-background/80 px-5 py-4 backdrop-blur-xl">
        <Link to="/sueno" className="grid h-9 w-9 place-items-center rounded-full bg-white shadow">
          <ArrowLeft className="h-4 w-4 text-primary" />
        </Link>
        <div className="flex-1">
          <p className="text-[10px] tracking-[0.25em] text-muted-foreground">PROGRAMACIÓN</p>
          <h1 className="text-lg font-bold text-primary">Dream Programmer</h1>
        </div>
        <div
          className="grid h-9 w-9 place-items-center rounded-full text-white"
          style={{ background: "var(--gradient-primary)" }}
        >
          <BrainCircuit className="h-4 w-4" />
        </div>
      </header>

      <div className="px-5 pt-2 pb-40 space-y-6">
        <MediaCarousel
          title="SKIN DEL USUARIO"
          items={SKINS as readonly CarouselItem[]}
          selectedId={skinId}
          onSelect={setSkinId}
        />
        <MediaCarousel
          title="ENTORNO DEL SUEÑO"
          items={SCENES as readonly CarouselItem[]}
          selectedId={sceneId}
          onSelect={setSceneId}
        />

        {/* Form */}
        <section ref={formRef} className="space-y-3">
          <p className="text-[10px] font-medium tracking-[0.25em] text-muted-foreground">
            — {editingId ? "EDITANDO INYECCIÓN" : "NUEVA INYECCIÓN"}
          </p>
          <div className="rounded-3xl bg-card p-4 ring-1 ring-border shadow-[var(--shadow-soft)] space-y-4">
            <div>
              <label className="text-[11px] font-semibold uppercase tracking-wider text-primary/70">
                Detalles extra (opcional)
              </label>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Agregá personajes, emociones o giros…"
                rows={3}
                className="mt-1.5 w-full resize-none rounded-2xl bg-secondary/60 px-3 py-2.5 text-sm outline-none ring-1 ring-transparent placeholder:text-muted-foreground focus:ring-primary"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[11px] font-semibold uppercase tracking-wider text-primary/70">
                  Fecha
                </label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "mt-1.5 w-full justify-start rounded-2xl bg-secondary/60 border-0 text-left text-xs font-normal",
                        !date && "text-muted-foreground",
                      )}
                    >
                      <CalendarIcon className="mr-1.5 h-3.5 w-3.5" />
                      {date ? format(date, "dd MMM yyyy", { locale: es }) : "Elegir"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={setDate}
                      initialFocus
                      className={cn("p-3 pointer-events-auto")}
                    />
                  </PopoverContent>
                </Popover>
              </div>
              <div>
                <label className="text-[11px] font-semibold uppercase tracking-wider text-primary/70">
                  Hora
                </label>
                <input
                  type="time"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="mt-1.5 w-full rounded-2xl bg-secondary/60 px-3 py-2 text-xs outline-none ring-1 ring-transparent focus:ring-primary"
                />
              </div>
            </div>

            <div>
              <label className="text-[11px] font-semibold uppercase tracking-wider text-primary/70">
                Banda sonora
              </label>
              <div className="mt-1.5 flex items-center gap-2 rounded-full bg-secondary/60 px-3 py-2.5 ring-1 ring-transparent focus-within:ring-primary">
                <Music className="h-4 w-4 text-primary/70" />
                <input
                  value={mediaUrl}
                  onChange={(e) => setMediaUrl(e.target.value)}
                  placeholder="Pegá link de Spotify o YouTube"
                  className="flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
                />
                <PlatformBadge platform={platform} />
              </div>
              <div className="mt-2 flex gap-2">
                {FREQUENCIES.map((f) => {
                  const active = frequency === f.id;
                  return (
                    <button
                      key={f.id}
                      onClick={() => setFrequency(active ? null : f.id)}
                      className={cn(
                        "flex-1 rounded-full px-2 py-1.5 text-[11px] font-semibold transition active:scale-95",
                        active
                          ? "text-white shadow-[var(--shadow-glow)]"
                          : "bg-secondary/60 text-primary ring-1 ring-border",
                      )}
                      style={active ? { background: "var(--gradient-primary)" } : undefined}
                    >
                      {f.label} · {f.hz}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="flex gap-2">
              {editingId && (
                <Button
                  variant="outline"
                  onClick={resetForm}
                  className="rounded-full"
                >
                  Cancelar
                </Button>
              )}
              <button
                onClick={submit}
                disabled={!canSubmit || isInjecting}
                className="flex flex-1 items-center justify-center gap-2 rounded-full py-3 text-sm font-semibold text-white shadow-[var(--shadow-glow)] transition disabled:opacity-50"
                style={{ background: "var(--gradient-primary)" }}
              >
                <Zap className="h-4 w-4" />
                {editingId ? "Actualizar inyección" : "Programar inyección en el cerebro"}
              </button>
            </div>
            {!canSubmit && (
              <p className="text-[11px] text-muted-foreground text-center">
                Elegí skin, entorno y fecha para programar.
              </p>
            )}
          </div>
        </section>

        {/* Schedule list */}
        <section className="space-y-2">
          <p className="text-[10px] font-medium tracking-[0.25em] text-muted-foreground">
            — CRONOGRAMA DE INYECCIONES
          </p>
          {sorted.length === 0 ? (
            <div className="rounded-3xl bg-card p-6 text-center ring-1 ring-border shadow-[var(--shadow-soft)]">
              <CalendarClock className="mx-auto h-7 w-7 text-primary/60" />
              <p className="mt-2 text-sm font-semibold text-foreground">
                Aún no programaste sueños
              </p>
              <p className="mt-1 text-xs text-muted-foreground">
                Elegí una skin y un entorno para empezar.
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              <AnimatePresence initial={false}>
                {sorted.map((it) => {
                  const sk = skinById(it.skinId);
                  const sc = sceneById(it.sceneId);
                  const fr = freqById(it.frequency ?? undefined);
                  return (
                  <motion.div
                    key={it.id}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -8 }}
                    transition={{ duration: 0.18 }}
                    className="rounded-3xl bg-card p-4 ring-1 ring-border shadow-[var(--shadow-soft)]"
                  >
                    <div className="flex items-start gap-3">
                       <div
                         className="relative h-10 w-10 shrink-0 overflow-hidden rounded-2xl text-white"
                         style={{ background: sk?.gradient ?? "var(--gradient-primary)" }}
                       >
                         {sk ? (
                           <img src={sk.image} alt={sk.name} className="absolute inset-0 h-full w-full object-cover" loading="lazy" />
                         ) : (
                           <span className="absolute inset-0 grid place-items-center"><BrainCircuit className="h-4 w-4" /></span>
                         )}
                       </div>
                      <div className="min-w-0 flex-1">
                        <p className="line-clamp-1 text-sm font-semibold text-foreground">
                          {sk?.name ?? "Sueño"}
                        </p>
                        {sc && (
                          <p className="text-[11px] text-primary/80">{sc.name}</p>
                        )}
                        {it.prompt && (
                          <p className="mt-0.5 line-clamp-2 text-[11px] text-muted-foreground">
                            {it.prompt}
                          </p>
                        )}
                        <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-muted-foreground">
                          <span className="inline-flex items-center gap-1">
                            <CalendarClock className="h-3 w-3" />
                            {format(new Date(it.scheduledAt), "dd MMM · HH:mm", { locale: es })}
                          </span>
                          <PlatformTag platform={it.platform} />
                          {fr && (
                            <span className="inline-flex items-center gap-1 rounded-full bg-primary/10 px-2 py-0.5 font-semibold text-primary">
                              {fr.label} · {fr.hz}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="mt-3 flex justify-end gap-2">
                      <button
                        onClick={() => setTrailerId(it.id)}
                        className="inline-flex items-center gap-1 rounded-full px-3 py-1.5 text-xs font-semibold text-white shadow-[var(--shadow-glow)] transition active:scale-95"
                        style={{ background: "var(--gradient-primary)" }}
                      >
                        <Play className="h-3 w-3 fill-white" /> Trailer
                      </button>
                      <button
                        onClick={() => startEdit(it)}
                        className="inline-flex items-center gap-1 rounded-full bg-secondary/60 px-3 py-1.5 text-xs font-medium text-primary transition active:scale-95"
                      >
                        <Pencil className="h-3 w-3" /> Editar
                      </button>
                      <button
                        onClick={() => removeItem(it.id)}
                        className="inline-flex items-center gap-1 rounded-full bg-destructive/10 px-3 py-1.5 text-xs font-medium text-destructive transition active:scale-95"
                      >
                        <Trash2 className="h-3 w-3" /> Borrar
                      </button>
                    </div>
                  </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>
          )}
        </section>
      </div>

      <InjectionOverlay
        open={isInjecting}
        skinName={skinById(skinId)?.name}
        sceneName={sceneById(sceneId)?.name}
        freqLabel={freqById(frequency ?? undefined) ? `${freqById(frequency ?? undefined)!.label} · ${freqById(frequency ?? undefined)!.hz}` : undefined}
      />

      <TrailerOverlay
        dream={trailerId ? items.find((i) => i.id === trailerId) ?? null : null}
        onClose={() => setTrailerId(null)}
      />
    </MobileShell>
  );
}

function InjectionOverlay({
  open,
  skinName,
  sceneName,
  freqLabel,
}: {
  open: boolean;
  skinName?: string;
  sceneName?: string;
  freqLabel?: string;
}) {
  const steps = [
    `Descargando skin ${skinName ?? "—"}…`,
    `Configurando entorno ${sceneName ?? "—"}…`,
    `Sincronizando audio ${freqLabel ?? "ambiente"}…`,
    `Inyectando en córtex…`,
  ];
  const [step, setStep] = useState(0);
  useEffect(() => {
    if (!open) {
      setStep(0);
      return;
    }
    const id = window.setInterval(() => {
      setStep((s) => Math.min(s + 1, steps.length));
    }, 500);
    return () => window.clearInterval(id);
  }, [open, steps.length]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 grid place-items-center bg-background/95 backdrop-blur-xl px-6"
        >
          <div className="w-full max-w-sm text-center">
            <div className="relative mx-auto mb-6 h-24 w-24">
              <motion.div
                className="absolute inset-0 rounded-full border-2 border-primary/30 border-t-primary"
                animate={{ rotate: 360 }}
                transition={{ duration: 1.2, repeat: Infinity, ease: "linear" }}
              />
              <motion.div
                className="absolute inset-3 grid place-items-center rounded-full text-white"
                style={{ background: "var(--gradient-primary)" }}
                animate={{ scale: [1, 1.08, 1] }}
                transition={{ duration: 1.2, repeat: Infinity }}
              >
                <BrainCircuit className="h-8 w-8" />
              </motion.div>
            </div>
            <p className="text-[10px] tracking-[0.3em] text-muted-foreground">INYECCIÓN EN CURSO</p>
            <h2 className="mt-1 text-xl font-bold text-primary">Cargando sueño…</h2>
            <ul className="mt-5 space-y-2 text-left">
              {steps.map((s, i) => {
                const done = i < step;
                const active = i === step;
                return (
                  <motion.li
                    key={i}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: done || active ? 1 : 0.35, x: 0 }}
                    className={cn(
                      "flex items-center gap-2 text-xs",
                      done && "text-primary line-through opacity-70",
                      active && "text-foreground font-semibold",
                    )}
                  >
                    <span
                      className={cn(
                        "grid h-4 w-4 place-items-center rounded-full text-[9px]",
                        done ? "bg-primary text-white" : "bg-secondary text-muted-foreground",
                      )}
                    >
                      {done ? <Check className="h-2.5 w-2.5" /> : i + 1}
                    </span>
                    {s}
                  </motion.li>
                );
              })}
            </ul>
            <div className="mt-5 h-1.5 w-full overflow-hidden rounded-full bg-secondary">
              <motion.div
                className="h-full"
                style={{ background: "var(--gradient-primary)" }}
                initial={{ width: "0%" }}
                animate={{ width: "100%" }}
                transition={{ duration: 2, ease: "linear" }}
              />
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

type CarouselItem = {
  id: string;
  name: string;
  tag: string;
  image: string;
  gradient: string;
};

function MediaCarousel({
  title,
  items,
  selectedId,
  onSelect,
}: {
  title: string;
  items: readonly CarouselItem[];
  selectedId: string | undefined;
  onSelect: (id: string) => void;
}) {
  const scrollRef = useRef<HTMLDivElement>(null);
  function scroll(dir: 1 | -1) {
    const el = scrollRef.current;
    if (!el) return;
    const card = el.querySelector<HTMLElement>("[data-carousel-card]");
    const step = card ? card.offsetWidth + 16 : el.clientWidth * 0.7;
    el.scrollBy({ left: dir * step, behavior: "smooth" });
  }
  return (
    <section className="space-y-2">
      <div className="flex items-center justify-between">
        <p className="text-[10px] font-medium tracking-[0.25em] text-muted-foreground">
          — {title}
        </p>
        <div className="flex gap-1.5">
          <button
            type="button"
            aria-label="Anterior"
            onClick={() => scroll(-1)}
            className="grid h-8 w-8 place-items-center rounded-full bg-card ring-1 ring-border shadow-sm transition active:scale-95"
          >
            <ChevronLeft className="h-4 w-4 text-primary" />
          </button>
          <button
            type="button"
            aria-label="Siguiente"
            onClick={() => scroll(1)}
            className="grid h-8 w-8 place-items-center rounded-full bg-card ring-1 ring-border shadow-sm transition active:scale-95"
          >
            <ChevronRight className="h-4 w-4 text-primary" />
          </button>
        </div>
      </div>
      <div
        ref={scrollRef}
        className="scrollbar-hide -mx-5 flex snap-x snap-mandatory gap-4 overflow-x-auto scroll-smooth px-8 pb-2"
      >
        {items.map((it) => {
          const active = selectedId === it.id;
          return (
            <button
              key={it.id}
              data-carousel-card
              onClick={() => onSelect(it.id)}
              className="snap-start shrink-0 basis-[60%] text-left transition active:scale-[0.97]"
            >
              <div
                className={cn(
                  "relative aspect-[3/4] overflow-hidden rounded-3xl text-white transition",
                  active
                    ? "ring-2 ring-primary shadow-[var(--shadow-glow)]"
                    : "ring-1 ring-border/60",
                )}
                style={{ background: it.gradient }}
              >
                <img
                  src={it.image}
                  alt={it.name}
                  loading="lazy"
                  className="absolute inset-0 h-full w-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
                {active && (
                  <span className="absolute right-2 top-2 grid h-6 w-6 place-items-center rounded-full bg-white text-primary shadow">
                    <Check className="h-3.5 w-3.5" />
                  </span>
                )}
                <p className="absolute bottom-3 left-3 right-3 text-sm font-bold leading-tight text-white drop-shadow-lg">
                  {it.name}
                </p>
              </div>
              <div className="mt-2.5">
                <span className="inline-flex rounded-full bg-muted px-2.5 py-0.5 text-[10px] font-medium text-muted-foreground">
                  {it.tag}
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </section>
  );
}

function PlatformBadge({ platform }: { platform: "spotify" | "youtube" | null }) {
  if (!platform) return null;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-semibold",
        platform === "spotify" ? "bg-[#1DB954]/15 text-[#178c40]" : "bg-[#FF0000]/10 text-[#c20000]",
      )}
    >
      {platform === "spotify" ? <SpotifyLogo /> : <YouTubeLogo />}
      {platform === "spotify" ? "Spotify" : "YouTube"}
    </span>
  );
}

function PlatformTag({ platform }: { platform: "spotify" | "youtube" | null }) {
  if (!platform) return <span className="text-muted-foreground/70">Sin audio</span>;
  return (
    <span className="inline-flex items-center gap-1">
      {platform === "spotify" ? <SpotifyLogo /> : <YouTubeLogo />}
      {platform === "spotify" ? "Spotify" : "YouTube"}
    </span>
  );
}

function SpotifyLogo() {
  return (
    <svg viewBox="0 0 24 24" className="h-3 w-3" fill="#1DB954" aria-hidden>
      <path d="M12 0a12 12 0 1 0 0 24 12 12 0 0 0 0-24Zm5.5 17.3a.75.75 0 0 1-1 .25c-2.8-1.7-6.3-2.1-10.5-1.1a.75.75 0 1 1-.3-1.4c4.5-1 8.4-.6 11.5 1.3.4.2.5.6.3 1Zm1.5-3.3a.94.94 0 0 1-1.3.3c-3.2-2-8-2.5-11.8-1.4a.94.94 0 1 1-.5-1.8c4.3-1.2 9.7-.6 13.3 1.6a.94.94 0 0 1 .3 1.3Zm.1-3.4c-3.8-2.3-10.2-2.5-13.9-1.4a1.12 1.12 0 1 1-.6-2.2c4.2-1.2 11.2-1 15.6 1.6a1.13 1.13 0 1 1-1.1 2Z" />
    </svg>
  );
}

function YouTubeLogo() {
  return (
    <svg viewBox="0 0 24 24" className="h-3 w-3.5" aria-hidden>
      <path fill="#FF0000" d="M23.5 6.2a3 3 0 0 0-2.1-2.1C19.6 3.6 12 3.6 12 3.6s-7.6 0-9.4.5A3 3 0 0 0 .5 6.2 31.2 31.2 0 0 0 0 12a31.2 31.2 0 0 0 .5 5.8 3 3 0 0 0 2.1 2.1c1.8.5 9.4.5 9.4.5s7.6 0 9.4-.5a3 3 0 0 0 2.1-2.1A31.2 31.2 0 0 0 24 12a31.2 31.2 0 0 0-.5-5.8Z" />
      <path fill="#fff" d="M9.6 15.6 15.8 12 9.6 8.4Z" />
    </svg>
  );
}

function TrailerOverlay({
  dream,
  onClose,
}: {
  dream: ScheduledDream | null;
  onClose: () => void;
}) {
  const [scene, setScene] = useState(0);
  const SCENE_MS = 1800;
  const totalScenes = 5;

  useEffect(() => {
    if (!dream) {
      setScene(0);
      return;
    }
    setScene(0);
    const id = window.setInterval(() => {
      setScene((s) => {
        if (s >= totalScenes - 1) {
          window.clearInterval(id);
          return s;
        }
        return s + 1;
      });
    }, SCENE_MS);
    return () => window.clearInterval(id);
  }, [dream]);

  if (!dream) return null;
  const sk = skinById(dream.skinId);
  const sc = sceneById(dream.sceneId);
  const fr = freqById(dream.frequency ?? undefined);
  const when = format(new Date(dream.scheduledAt), "EEE dd MMM · HH:mm", { locale: es });

  const sceneBg = sc?.gradient ?? "linear-gradient(120deg,#0f172a,#1e1b4b,#000)";

  return (
    <AnimatePresence>
      {dream && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[60] overflow-hidden bg-black text-white"
        >
          {/* Animated scenic background */}
          <motion.div
            key={scene}
            initial={{ scale: 1.15, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="absolute inset-0"
            style={{ background: sceneBg }}
          />
          {/* Vignette + grain */}
          <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_40%,rgba(0,0,0,0.75)_100%)]" />
          <div
            className="pointer-events-none absolute inset-0 opacity-[0.08] mix-blend-overlay"
            style={{
              backgroundImage:
                "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='120' height='120'><filter id='n'><feTurbulence baseFrequency='0.9'/></filter><rect width='100%' height='100%' filter='url(%23n)' opacity='0.6'/></svg>\")",
            }}
          />

          {/* Cinematic bars */}
          <motion.div
            initial={{ height: 0 }}
            animate={{ height: 56 }}
            transition={{ duration: 0.5 }}
            className="absolute left-0 right-0 top-0 z-10 bg-black"
          />
          <motion.div
            initial={{ height: 0 }}
            animate={{ height: 56 }}
            transition={{ duration: 0.5 }}
            className="absolute left-0 right-0 bottom-0 z-10 bg-black"
          />

          {/* Close */}
          <button
            onClick={onClose}
            className="absolute right-4 top-4 z-30 grid h-9 w-9 place-items-center rounded-full bg-white/15 backdrop-blur-md text-white active:scale-95"
            aria-label="Cerrar trailer"
          >
            <X className="h-4 w-4" />
          </button>

          {/* Progress segments */}
          <div className="absolute left-4 right-4 top-5 z-30 flex gap-1">
            {Array.from({ length: totalScenes }).map((_, i) => (
              <div key={i} className="h-0.5 flex-1 overflow-hidden rounded-full bg-white/20">
                <motion.div
                  className="h-full bg-white"
                  initial={{ width: i < scene ? "100%" : "0%" }}
                  animate={{ width: i <= scene ? "100%" : "0%" }}
                  transition={{ duration: i === scene ? SCENE_MS / 1000 : 0.2, ease: "linear" }}
                />
              </div>
            ))}
          </div>

          {/* Scene content */}
          <div className="relative z-20 grid h-full place-items-center px-8">
            <AnimatePresence mode="wait">
              {scene === 0 && (
                <motion.div
                  key="s0"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.6 }}
                  className="text-center"
                >
                  <p className="text-[10px] tracking-[0.5em] text-white/70">SLEEP STOCK PRESENTA</p>
                  <motion.h1
                    initial={{ letterSpacing: "0.2em", opacity: 0 }}
                    animate={{ letterSpacing: "0.05em", opacity: 1 }}
                    transition={{ duration: 1.2, ease: "easeOut" }}
                    className="mt-3 text-3xl font-black uppercase leading-none drop-shadow-2xl"
                  >
                    Una inyección onírica
                  </motion.h1>
                  <div className="mx-auto mt-4 h-px w-16 bg-white/60" />
                </motion.div>
              )}

              {scene === 1 && sk && (
                <motion.div
                  key="s1"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="text-center"
                >
                  <p className="text-[10px] tracking-[0.5em] text-white/70">PROTAGONISTA</p>
                   <motion.div
                     initial={{ scale: 0.4, rotate: -15, opacity: 0 }}
                     animate={{ scale: 1, rotate: 0, opacity: 1 }}
                     transition={{ type: "spring", damping: 12, stiffness: 120 }}
                     className="relative mx-auto mt-4 h-40 w-40 overflow-hidden rounded-[2.5rem] shadow-2xl"
                     style={{ background: sk.gradient }}
                   >
                     <img src={sk.image} alt={sk.name} className="absolute inset-0 h-full w-full object-cover" />
                   </motion.div>
                  <motion.h2
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 }}
                    className="mt-5 text-2xl font-bold drop-shadow"
                  >
                    {sk.name}
                  </motion.h2>
                  <p className="text-xs text-white/70">{sk.tag}</p>
                </motion.div>
              )}

              {scene === 2 && sc && (
                <motion.div
                  key="s2"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="text-center"
                >
                  <p className="text-[10px] tracking-[0.5em] text-white/70">ESCENARIO</p>
                   <motion.div
                     initial={{ scale: 1.5, opacity: 0 }}
                     animate={{ scale: 1, opacity: 1 }}
                     transition={{ duration: 1 }}
                     className="relative mx-auto mt-4 h-48 w-72 overflow-hidden rounded-[2rem] shadow-2xl"
                   >
                     <img src={sc.image} alt={sc.name} className="absolute inset-0 h-full w-full object-cover" />
                     <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                   </motion.div>
                  <motion.h2
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                    className="mt-3 text-3xl font-black uppercase tracking-wide drop-shadow"
                  >
                    {sc.name}
                  </motion.h2>
                </motion.div>
              )}

              {scene === 3 && (
                <motion.div
                  key="s3"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="w-full max-w-xs text-center"
                >
                  <p className="text-[10px] tracking-[0.5em] text-white/70">BANDA SONORA</p>
                  <div className="mt-5 flex items-end justify-center gap-1.5 h-20">
                    {Array.from({ length: 18 }).map((_, i) => (
                      <motion.span
                        key={i}
                        className="w-1.5 rounded-full bg-white"
                        animate={{ height: ["20%", "100%", "30%", "80%", "25%"] }}
                        transition={{
                          duration: 1.4,
                          repeat: Infinity,
                          delay: i * 0.05,
                          ease: "easeInOut",
                        }}
                        style={{ height: "30%" }}
                      />
                    ))}
                  </div>
                  {fr ? (
                    <p className="mt-5 text-xl font-bold">
                      {fr.label} · <span className="text-white/70">{fr.hz}</span>
                    </p>
                  ) : (
                    <p className="mt-5 text-xl font-bold">Ambient drift</p>
                  )}
                  {dream.platform && (
                    <p className="mt-1 text-xs uppercase tracking-widest text-white/70">
                      vía {dream.platform}
                    </p>
                  )}
                </motion.div>
              )}

              {scene === 4 && (
                <motion.div
                  key="s4"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="text-center"
                >
                  <p className="text-[10px] tracking-[0.5em] text-white/70">PRÓXIMAMENTE</p>
                  <motion.h2
                    initial={{ scale: 0.7, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ type: "spring", damping: 14 }}
                    className="mt-4 text-5xl font-black uppercase leading-[0.95] tracking-tight drop-shadow-2xl"
                  >
                    {when}
                  </motion.h2>
                  {dream.prompt && (
                    <motion.p
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.5 }}
                      className="mx-auto mt-5 max-w-[18rem] text-sm italic text-white/80"
                    >
                      “{dream.prompt}”
                    </motion.p>
                  )}
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 1 }}
                    className="mt-6 inline-flex items-center gap-2 rounded-full bg-white/15 px-4 py-1.5 text-[10px] tracking-[0.4em] backdrop-blur-md"
                  >
                    SLEEP STOCK · DREAM PROGRAMMER
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Replay when finished */}
          {scene === totalScenes - 1 && (
            <motion.button
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.4 }}
              onClick={() => setScene(0)}
              className="absolute bottom-20 left-1/2 z-30 -translate-x-1/2 rounded-full bg-white px-5 py-2 text-xs font-bold text-black active:scale-95"
            >
              <Play className="mr-1.5 inline h-3 w-3 fill-black" /> Repetir trailer
            </motion.button>
          )}
        </motion.div>
      )}
    </AnimatePresence>
  );
}