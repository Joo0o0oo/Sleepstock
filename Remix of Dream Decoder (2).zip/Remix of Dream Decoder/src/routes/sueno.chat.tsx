import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useRef, useState } from "react";
import { ArrowLeft, ArrowUp, Sparkles, History, Trash2, Moon } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { z } from "zod";
import { MobileShell } from "@/components/MobileShell";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { interpretDream } from "@/lib/ai.functions";
import { saveDream, getDreams, type Dream } from "@/lib/dreams-store";
import { getHistory, appendTurn, clearHistory, type ChatTurn } from "@/lib/sleepbot-history";
import dream1 from "@/assets/dream-1.jpg";

export const Route = createFileRoute("/sueno/chat")({
  validateSearch: z.object({ q: z.string().optional() }),
  head: () => ({ meta: [{ title: "Decodificador de sueños — Sleep Stock" }] }),
  component: DreamChatPage,
});

type Msg = { role: "user" | "assistant"; content: string };

function DreamChatPage() {
  const { q } = Route.useSearch();
  const interpret = useServerFn(interpretDream);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState(q ?? "");
  const [loading, setLoading] = useState(false);
  const [dreams, setDreams] = useState<Dream[]>([]);
  const [historyOpen, setHistoryOpen] = useState(false);
  const triggered = useRef(false);
  const endRef = useRef<HTMLDivElement>(null);

  // Hydrate from localStorage on mount
  useEffect(() => {
    const stored = getHistory();
    if (stored.length) {
      setMessages(stored.map((t: ChatTurn) => ({ role: t.role, content: t.content })));
    }
    setDreams(getDreams());
  }, []);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  async function send(text: string) {
    if (!text.trim() || loading) return;
    setMessages((m) => [...m, { role: "user", content: text }]);
    appendTurn({ role: "user", content: text });
    setInput("");
    setLoading(true);
    try {
      const { analysis, title } = await interpret({ data: { relato: text } });
      setMessages((m) => [...m, { role: "assistant", content: analysis }]);
      appendTurn({ role: "assistant", content: analysis });
      saveDream({
        id: String(Date.now()),
        title,
        date: new Date().toLocaleDateString("es-AR", { day: "numeric", month: "long", year: "numeric" }),
        image: dream1,
        analysis,
      });
      setDreams(getDreams());
    } catch (e) {
      const err = `⚠️ ${(e as Error).message}`;
      setMessages((m) => [...m, { role: "assistant", content: err }]);
      appendTurn({ role: "assistant", content: err });
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (q && q.trim() && !triggered.current) {
      triggered.current = true;
      void send(q);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q]);

  function handleClear() {
    if (!confirm("¿Borrar toda la conversación con Sleep BOT? Los sueños guardados se conservan.")) return;
    clearHistory();
    setMessages([]);
  }

  return (
    <MobileShell>
      <header className="sticky top-0 z-20 flex items-center gap-3 bg-background/80 px-5 py-4 backdrop-blur-xl">
        <Link to="/sueno" className="grid h-9 w-9 place-items-center rounded-full bg-white shadow">
          <ArrowLeft className="h-4 w-4 text-primary" />
        </Link>
        <div className="flex-1">
          <p className="text-[10px] tracking-[0.25em] text-muted-foreground">DECODIFICADOR</p>
          <h1 className="text-lg font-bold text-primary">Sleep BOT</h1>
        </div>
        <Sheet open={historyOpen} onOpenChange={setHistoryOpen}>
          <SheetTrigger asChild>
            <button
              className="grid h-9 w-9 place-items-center rounded-full bg-white shadow ring-1 ring-border"
              aria-label="Historial"
            >
              <History className="h-4 w-4 text-primary" />
            </button>
          </SheetTrigger>
          <SheetContent side="right" className="w-[88%] max-w-[380px] overflow-y-auto p-0">
            <SheetHeader className="border-b border-border px-5 py-4">
              <SheetTitle className="text-left text-base font-bold text-primary">
                Tus sueños registrados
              </SheetTitle>
              <p className="text-left text-xs text-muted-foreground">
                {dreams.length} {dreams.length === 1 ? "sueño guardado" : "sueños guardados"}
              </p>
            </SheetHeader>
            <div className="space-y-2 p-4">
              {dreams.length === 0 ? (
                <div className="rounded-2xl bg-secondary/50 p-4 text-center text-sm text-muted-foreground">
                  Todavía no registraste ningún sueño.
                </div>
              ) : (
                dreams.map((d) => (
                  <Link
                    key={d.id}
                    to="/sueno/$id"
                    params={{ id: d.id }}
                    onClick={() => setHistoryOpen(false)}
                    className="flex gap-3 rounded-2xl bg-card p-2.5 ring-1 ring-border transition active:scale-[0.98]"
                  >
                    <img
                      src={d.image}
                      alt={d.title}
                      className="h-14 w-14 shrink-0 rounded-xl object-cover"
                      loading="lazy"
                    />
                    <div className="min-w-0 flex-1">
                      <p className="text-[10px] text-muted-foreground">{d.date}</p>
                      <p className="truncate text-sm font-semibold text-primary">{d.title}</p>
                      <p className="mt-0.5 flex items-center gap-1 text-[10px] text-muted-foreground">
                        <Moon className="h-3 w-3" /> Decodificado
                      </p>
                    </div>
                  </Link>
                ))
              )}
            </div>
            {messages.length > 0 && (
              <div className="border-t border-border p-4">
                <button
                  onClick={() => {
                    setHistoryOpen(false);
                    handleClear();
                  }}
                  className="flex w-full items-center justify-center gap-2 rounded-full bg-secondary/70 px-4 py-3 text-sm font-medium text-muted-foreground transition hover:text-destructive"
                >
                  <Trash2 className="h-4 w-4" />
                  Limpiar conversación
                </button>
              </div>
            )}
          </SheetContent>
        </Sheet>
      </header>

      <div className="px-5 pt-4 pb-40 space-y-4">
        {messages.length === 0 && (
          <div className="rounded-3xl bg-card p-5 ring-1 ring-border shadow-[var(--shadow-soft)]">
            <Sparkles className="h-6 w-6 text-primary" />
            <p className="mt-3 font-semibold text-foreground">Contame tu sueño</p>
            <p className="mt-1 text-sm text-muted-foreground">
              Escribí con el mayor detalle posible: lugares, personas, emociones, colores. La IA va a interpretar los símbolos.
            </p>
            {dreams.length > 0 && (
              <button
                onClick={() => setHistoryOpen(true)}
                className="mt-4 flex items-center gap-2 rounded-full bg-secondary/70 px-3 py-2 text-xs font-medium text-primary"
              >
                <History className="h-3.5 w-3.5" />
                Ver tus {dreams.length} {dreams.length === 1 ? "sueño" : "sueños"} registrados
              </button>
            )}
          </div>
        )}
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[85%] rounded-3xl px-4 py-3 text-sm ${
                m.role === "user"
                  ? "rounded-br-md text-white"
                  : "rounded-bl-md bg-card text-foreground ring-1 ring-border"
              }`}
              style={m.role === "user" ? { background: "var(--gradient-primary)" } : undefined}
            >
              {m.role === "assistant" ? (
                <div className="prose prose-sm prose-headings:text-primary prose-strong:text-primary max-w-none">
                  <ReactMarkdown>{m.content}</ReactMarkdown>
                </div>
              ) : (
                m.content
              )}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex gap-1 px-2">
            {[0, 1, 2].map((i) => (
              <span
                key={i}
                className="h-2 w-2 animate-bounce rounded-full bg-primary"
                style={{ animationDelay: `${i * 120}ms` }}
              />
            ))}
          </div>
        )}
        <div ref={endRef} />
      </div>

      <div className="fixed bottom-24 left-1/2 z-30 w-full max-w-[430px] -translate-x-1/2 px-5">
        <div className="flex items-center gap-2 rounded-full bg-white px-4 py-3 shadow-[var(--shadow-glow)] ring-1 ring-border">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && send(input)}
            placeholder="Escribí tu sueño…"
            className="flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
          />
          <button
            onClick={() => send(input)}
            disabled={loading || !input.trim()}
            className="grid h-9 w-9 place-items-center rounded-full text-white disabled:opacity-50"
            style={{ background: "var(--gradient-primary)" }}
            aria-label="Enviar"
          >
            <ArrowUp className="h-4 w-4" />
          </button>
        </div>
      </div>
    </MobileShell>
  );
}
