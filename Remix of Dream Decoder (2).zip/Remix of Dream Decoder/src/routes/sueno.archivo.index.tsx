import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, MoreVertical, Sparkles } from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { MobileShell } from "@/components/MobileShell";
import {
  getArchivo,
  formatDuration,
  type CapturedDream,
  type DreamPhase,
} from "@/lib/archivo-onirico-mock";

export const Route = createFileRoute("/sueno/archivo/")({
  head: () => ({
    meta: [
      { title: "Archivo Onírico — HYPN" },
      {
        name: "description",
        content:
          "Tus sueños capturados por la HYPN Band. Reproducilos cuando quieras.",
      },
    ],
  }),
  component: ArchivoPage,
});

const FILTERS = ["Todos", "REM", "Lúcido", "Pesadilla", "Favoritos"] as const;
type Filter = (typeof FILTERS)[number];

function ArchivoPage() {
  const [filter, setFilter] = useState<Filter>("Todos");
  const [items, setItems] = useState<CapturedDream[]>([]);
  useEffect(() => setItems(getArchivo()), []);

  const filtered = useMemo(() => {
    if (filter === "Todos") return items;
    if (filter === "Favoritos") return items.filter((d) => d.favorito);
    return items.filter((d) => d.phase === filter);
  }, [items, filter]);

  const totalSec = items.reduce((s, d) => s + d.durationSec, 0);

  return (
    <MobileShell>
      <header className="sticky top-0 z-20 flex items-center gap-3 bg-white/85 px-5 py-4 backdrop-blur-xl">
        <Link
          to="/sueno"
          className="grid h-9 w-9 place-items-center rounded-full bg-white shadow ring-1 ring-border"
        >
          <ArrowLeft className="h-4 w-4 text-primary" />
        </Link>
        <div>
          <p className="hypn-eyebrow">— DISPOSITIVO HYPN</p>
          <h1 className="text-lg font-bold text-primary">Archivo Onírico</h1>
        </div>
      </header>

      <div className="px-5 pt-2 pb-32 space-y-5">
        <HeroCard
          nights={items.length}
          totalSec={totalSec}
          fidelity={
            items.length
              ? Math.round(
                  items.reduce((s, d) => s + d.fidelity, 0) / items.length,
                )
              : 0
          }
        />

        <div className="flex gap-2 overflow-x-auto scrollbar-hide -mx-5 px-5">
          {FILTERS.map((c) => (
            <button
              key={c}
              onClick={() => setFilter(c)}
              className={`shrink-0 rounded-full px-4 py-1.5 text-xs font-semibold ring-1 transition ${
                filter === c
                  ? "bg-primary text-primary-foreground ring-primary shadow-[var(--shadow-glow)]"
                  : "bg-white text-muted-foreground ring-border"
              }`}
            >
              {c}
            </button>
          ))}
        </div>

        {filtered.length === 0 ? (
          <div className="rounded-3xl bg-white p-6 ring-1 ring-border text-center text-sm text-muted-foreground">
            No hay capturas en esta categoría todavía.
          </div>
        ) : (
          <div className="space-y-4">
            {filtered.map((d, i) => (
              <DreamCard key={d.id} d={d} index={i} />
            ))}
          </div>
        )}
      </div>
    </MobileShell>
  );
}

function HeroCard({
  nights,
  totalSec,
  fidelity,
}: {
  nights: number;
  totalSec: number;
  fidelity: number;
}) {
  const hours = (totalSec / 3600).toFixed(1);
  return (
    <div className="relative overflow-hidden rounded-3xl bg-white p-5 ring-1 ring-border shadow-[0_24px_60px_-30px_rgba(107,33,217,0.4)]">
      <div className="flex items-center justify-between">
        <span className="hypn-chip">● HYPN BAND CONECTADA</span>
        <span className="text-[10px] tracking-[0.2em] text-muted-foreground">
          v4.2
        </span>
      </div>

      <p className="hypn-display mt-4 text-[40px] text-foreground">
        {nights}
        <span className="text-primary"> NOCHES</span>
      </p>
      <p className="mt-1 text-sm text-muted-foreground">
        Capturadas y reproducibles
      </p>

      <div className="mt-4 grid grid-cols-2 gap-3">
        <Metric label="REM TOTAL" value={`${hours}h`} />
        <Metric label="FIDELIDAD" value={`${fidelity}%`} accent />
      </div>

      <Waveform className="mt-4 h-10 w-full" />
    </div>
  );
}

function Metric({
  label,
  value,
  accent = false,
}: {
  label: string;
  value: string;
  accent?: boolean;
}) {
  return (
    <div className="rounded-2xl bg-[#FAF8FF] p-3 ring-1 ring-border">
      <p className="text-[9px] font-semibold tracking-[0.22em] text-muted-foreground">
        {label}
      </p>
      <p
        className={`mt-1 font-display text-xl font-extrabold tracking-tight ${
          accent ? "text-primary" : "text-foreground"
        }`}
      >
        {value}
      </p>
    </div>
  );
}

export function Waveform({ className = "" }: { className?: string }) {
  const bars = Array.from({ length: 48 }, (_, i) =>
    Math.abs(Math.sin(i / 2.1) * 0.7 + Math.sin(i / 5) * 0.3),
  );
  return (
    <div className={`flex items-end gap-[2px] ${className}`}>
      {bars.map((b, i) => (
        <span
          key={i}
          className="flex-1 rounded-sm bg-primary/60"
          style={{ height: `${Math.max(8, b * 100)}%` }}
        />
      ))}
    </div>
  );
}

const RELATIVE = ["Hace 1 h", "Hace 8 h", "Ayer", "Hace 2 d", "Hace 3 d", "Hace 4 d", "Hace 5 d", "Hace 1 sem"];

// Cache de URLs ya pre-cargadas para no duplicar trabajo
const prefetched = new Set<string>();
function prefetchVideo(url?: string) {
  if (!url || prefetched.has(url) || typeof window === "undefined") return;
  prefetched.add(url);
  // Pre-cargamos los primeros bytes del MP4: rápido y suficiente para abrir el player al instante.
  const v = document.createElement("video");
  v.src = url;
  v.preload = "auto";
  v.muted = true;
  // No lo agregamos al DOM: el browser igual inicia la descarga al setear src+preload.
}

function DreamCard({ d, index }: { d: CapturedDream; index: number }) {
  const eyebrow =
    index === 0
      ? "SUEÑO RECIENTE"
      : d.phase === "Lúcido"
        ? "SUEÑO LÚCIDO"
        : d.phase === "Pesadilla"
          ? "PESADILLA"
          : d.phase === "NREM"
            ? "FRAGMENTO NREM"
            : "FASE REM";
  const relative = RELATIVE[index] ?? `${d.date}`;
  const previewPct = 30 + ((index * 17) % 50);

  const onIntent = useCallback(() => prefetchVideo(d.videoUrl), [d.videoUrl]);

  return (
    <Link
      to="/sueno/archivo/$id"
      params={{ id: d.id }}
      onPointerEnter={onIntent}
      onPointerDown={onIntent}
      onFocus={onIntent}
      className="block rounded-3xl bg-white p-4 ring-1 ring-border shadow-[var(--shadow-soft)] transition active:scale-[0.99]"
    >
      <div className="flex items-center justify-between">
        <span className="inline-flex items-center gap-1.5 rounded-full bg-violet-100 px-3 py-1 text-[10px] font-bold tracking-[0.18em] text-primary">
          <Sparkles className="h-3 w-3" />
          {eyebrow}
        </span>
        <div className="flex items-center gap-2">
          <span className="text-[11px] text-muted-foreground">{relative}</span>
          <MoreVertical className="h-4 w-4 text-muted-foreground" />
        </div>
      </div>

      <DreamThumb d={d} eager={index < 2} className="mt-3 aspect-[16/9] w-full rounded-2xl" />

      <div className="mt-4 flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <p className="hypn-eyebrow text-primary">— TÍTULO DEL SUEÑO</p>
          <h3 className="hypn-display mt-1 text-[22px] leading-tight text-foreground">
            {d.title.replace(/\s#\d+$/, "")}
          </h3>
          <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">
            {d.narrative}
          </p>
        </div>
        <span className="shrink-0 inline-flex items-center gap-1 rounded-full bg-violet-100 px-2.5 py-1 text-[10px] font-bold text-primary">
          <span className="rounded-md bg-primary px-1.5 py-0.5 text-[9px] text-primary-foreground">
            {d.phase.toUpperCase()}
          </span>
          {d.fidelity}%
        </span>
      </div>

      <div className="mt-4">
        <div className="relative h-1 w-full rounded-full bg-violet-100">
          <div
            className="absolute left-0 top-0 h-full rounded-full bg-primary"
            style={{ width: `${previewPct}%` }}
          />
          <div
            className="absolute top-1/2 h-3 w-3 -translate-y-1/2 rounded-full bg-primary ring-2 ring-white"
            style={{ left: `calc(${previewPct}% - 6px)` }}
          />
        </div>
        <div className="mt-2 flex justify-between text-[10px] font-mono text-muted-foreground">
          <span>{formatDuration(Math.round((d.durationSec * previewPct) / 100))}</span>
          <span>{formatDuration(d.durationSec)}</span>
        </div>
      </div>
    </Link>
  );
}

/**
 * Thumbnail real con lazy-loading: el <video> solo monta cuando la card
 * entra (o se acerca) al viewport. Mientras tanto, mostramos el gradiente
 * de fondo para evitar layout shifts y ahorrar ancho de banda.
 */
export function DreamThumb({
  d,
  className = "",
  eager = false,
}: {
  d: CapturedDream;
  className?: string;
  eager?: boolean;
}) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [visible, setVisible] = useState(eager);

  useEffect(() => {
    if (visible || !ref.current || typeof IntersectionObserver === "undefined") return;
    const el = ref.current;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          setVisible(true);
          io.disconnect();
        }
      },
      { rootMargin: "400px 0px" }, // pre-cargamos antes de que se vea
    );
    io.observe(el);
    return () => io.disconnect();
  }, [visible]);

  return (
    <div
      ref={ref}
      className={`relative overflow-hidden ${className}`}
      style={{ background: d.gradient }}
    >
      {visible && d.videoUrl ? (
        <video
          // #t=0.1 fuerza al browser a renderizar un frame inicial incluso si autoplay falla
          src={`${d.videoUrl}#t=0.1`}
          autoPlay
          muted
          loop
          playsInline
          preload="metadata"
          className="h-full w-full object-cover"
        />
      ) : null}
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/15 via-transparent to-white/10" />
      <span
        className="absolute right-3 top-3 text-2xl drop-shadow"
        aria-hidden
      >
        {d.glyph}
      </span>
    </div>
  );
}

export function PhaseBadge({ phase }: { phase: DreamPhase }) {
  const map: Record<DreamPhase, string> = {
    REM: "bg-violet-100 text-violet-700",
    "Lúcido": "bg-emerald-100 text-emerald-700",
    Pesadilla: "bg-rose-100 text-rose-700",
    NREM: "bg-slate-200 text-slate-700",
  };
  return (
    <span
      className={`rounded-md px-1.5 py-0.5 text-[9px] font-bold tracking-wider ${map[phase]}`}
    >
      {phase.toUpperCase()}
    </span>
  );
}
